import tkinter as tk
from tkinter import ttk
import sql
import gui

def main() :
    gui.management_window()

if __name__ == '__main__':
    main()
